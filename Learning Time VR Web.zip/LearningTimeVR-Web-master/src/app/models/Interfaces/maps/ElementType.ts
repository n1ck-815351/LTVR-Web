export enum ElementType {
    None = 0,
    Class = 1,
    Subject = 2,
    Lesson = 3,
    Content = 4
}