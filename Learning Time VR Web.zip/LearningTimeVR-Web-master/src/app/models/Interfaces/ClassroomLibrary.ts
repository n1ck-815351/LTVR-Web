export interface ClassroomLibrary {
    id: string;
    schoolId: string;
    title: string;
    description: string;
    authors: string[];
    classes: string[];
}
