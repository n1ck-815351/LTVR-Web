import { Classroom } from "../Classroom";

export interface EditDialog {
    
    confirmed:boolean;
    changedElement:any;
    
}
