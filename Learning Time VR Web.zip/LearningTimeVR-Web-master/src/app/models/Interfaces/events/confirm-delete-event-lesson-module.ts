export interface ConfirmDeleteEventLessonModule {
    confirm:boolean;
    classID:string|null;
    lessonModuleID:string|null;
}
