export interface ConfirmDeleteEventWithID {
    confirm: boolean;
    id: string | null;
}
