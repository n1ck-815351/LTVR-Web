export interface CreatorDialog {
    confirmed: boolean;
    title:string;
    description:string;
    tags:string;
    optionalArgs:any;
}
