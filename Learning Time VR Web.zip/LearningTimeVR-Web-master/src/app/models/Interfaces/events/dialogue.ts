export interface Dialogue {
    result: boolean;
}
