import { BaseUser } from "./BaseUser";

export interface Admin {
    id:string|null;
    baseUser:BaseUser;
}
