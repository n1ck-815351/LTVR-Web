import { BaseUser } from "./BaseUser";

export interface Moderator {
    id: string | null;

    baseUser:BaseUser;
}
