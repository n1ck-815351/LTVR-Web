export interface School {
    id: string;
    organizationId: string;
    title: string;
    description: string;
    users: string[];
    classLibraries: string[];
}
