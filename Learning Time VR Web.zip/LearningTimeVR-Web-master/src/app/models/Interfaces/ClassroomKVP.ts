export interface ClassroomKVP {
    id: string;
    title: string;
}