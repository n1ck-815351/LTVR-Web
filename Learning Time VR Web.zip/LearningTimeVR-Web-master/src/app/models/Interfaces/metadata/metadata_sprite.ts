export interface metadata_sprite {
    reference?:string;
    width?:number;
    height?:number;
    
}