export interface metadata_location {
    id:string|null;
    devDescription: string | null;
    dateCreated: string | null;
    dateUpdated: string | null;
    label: string | null;
    sceneName: string | null;
    sceneIndex: number | null;
}