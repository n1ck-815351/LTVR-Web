export interface DropdownOption {
    value: string;
    text: string;
}