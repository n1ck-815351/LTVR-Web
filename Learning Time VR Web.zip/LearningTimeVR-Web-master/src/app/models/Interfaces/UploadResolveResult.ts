export interface UploadResolveResult {
    url:string;
    fileName:string;
}
