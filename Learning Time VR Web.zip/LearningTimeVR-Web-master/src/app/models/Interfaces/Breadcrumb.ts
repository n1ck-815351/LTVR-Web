export interface Breadcrumb {
    title: string;
    url: string;
}