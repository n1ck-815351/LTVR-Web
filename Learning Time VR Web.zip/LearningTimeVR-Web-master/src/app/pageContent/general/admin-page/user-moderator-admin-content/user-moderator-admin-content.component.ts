import { Component } from '@angular/core';

@Component({
  selector: 'app-user-moderator-admin-content',
  templateUrl: './user-moderator-admin-content.component.html',
  styleUrls: ['./user-moderator-admin-content.component.scss']
})
export class UserModeratorAdminContentComponent {

}
