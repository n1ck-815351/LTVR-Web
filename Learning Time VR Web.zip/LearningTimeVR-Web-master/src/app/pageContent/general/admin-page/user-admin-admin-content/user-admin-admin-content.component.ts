import { Component } from '@angular/core';

@Component({
  selector: 'app-user-admin-admin-content',
  templateUrl: './user-admin-admin-content.component.html',
  styleUrls: ['./user-admin-admin-content.component.scss']
})
export class UserAdminAdminContentComponent {

}
