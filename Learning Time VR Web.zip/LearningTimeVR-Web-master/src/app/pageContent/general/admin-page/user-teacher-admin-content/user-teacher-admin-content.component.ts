import { Component } from '@angular/core';

@Component({
  selector: 'app-user-teacher-admin-content',
  templateUrl: './user-teacher-admin-content.component.html',
  styleUrls: ['./user-teacher-admin-content.component.scss']
})
export class UserTeacherAdminContentComponent {

}
