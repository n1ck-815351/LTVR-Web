import { Component } from '@angular/core';

@Component({
  selector: 'app-emersion-image',
  templateUrl: './emersion-image.component.html',
  styleUrls: ['./emersion-image.component.scss']
})
export class EmersionImageComponent {

}
