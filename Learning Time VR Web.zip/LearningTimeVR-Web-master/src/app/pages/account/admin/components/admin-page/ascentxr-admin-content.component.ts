import { Component } from '@angular/core';

@Component({
  selector: 'app-ascentxr-admin-content',
  templateUrl: './ascentxr-admin-content.component.html',
  styleUrls: ['./ascentxr-admin-content.component.scss']
})
export class AscentxrAdminContentComponent {

}
