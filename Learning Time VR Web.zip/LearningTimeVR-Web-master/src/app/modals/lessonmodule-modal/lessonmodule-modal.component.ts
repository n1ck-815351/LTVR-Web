import { Component } from '@angular/core';

@Component({
  selector: 'app-lessonmodule-modal',
  templateUrl: './lessonmodule-modal.component.html',
  styleUrls: ['./lessonmodule-modal.component.scss']
})
export class LessonmoduleModalComponent {

}
