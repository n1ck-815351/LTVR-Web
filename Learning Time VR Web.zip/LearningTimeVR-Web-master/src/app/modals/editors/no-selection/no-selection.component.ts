import { Component } from '@angular/core';

@Component({
  selector: 'app-no-selection',
  templateUrl: './no-selection.component.html',
  styleUrls: ['./no-selection.component.scss']
})
export class NoSelectionComponent {

}
