export const environment = {
  firebase: {
    projectId: 'learningtimevr-2023',
    appId: '1:226622560195:web:7ca63003a7097eb8694f76',
    storageBucket: 'learningtimevr-2023.appspot.com',
    locationId: 'us-central',
    apiKey: 'AIzaSyDYIqQBq_Pgk_xdCgnMPL6iO2dKv6nPmAI',
    authDomain: 'learningtimevr-2023.firebaseapp.com',
    messagingSenderId: '226622560195',
    measurementId: 'G-L9K1GHPMT5',
  },};
